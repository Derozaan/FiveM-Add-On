Citizen.CreateThread(function()
	--   Skyline
	AddTextEntry('0x38E073D7', 'Test')
	AddTextEntry('0xF4642C6F', 'ISonofUgly')

end)
